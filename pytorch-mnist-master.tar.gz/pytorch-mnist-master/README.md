# Deep learning Experiment 
# Handwritten digit recognition based on shallow neural network

1. The report template is available on content page of experiments.


The reference code has been published in this repository.

## Usage
firstly run ```python train.py``` to get the pre-trained model, then run ```python main.py``` to start the web application.